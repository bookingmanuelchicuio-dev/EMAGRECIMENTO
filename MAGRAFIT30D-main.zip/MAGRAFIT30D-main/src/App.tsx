import { Shield, Clock, Star, CheckCircle, Zap, Heart, Activity, Dumbbell, Users, ChevronRight, Flame } from 'lucide-react';

const WHATSAPP_LINK = 'https://chat.whatsapp.com/DoYJfOfRON1KT3zn0DQL1n';

function CTAButton({ className = '' }: { className?: string }) {
  return (
    <a
      href={WHATSAPP_LINK}
      target="_blank"
      rel="noopener noreferrer"
      className={`inline-flex items-center justify-center gap-2 bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-400 text-white font-black uppercase tracking-[2px] px-10 py-4 rounded-full transition-all duration-300 hover:scale-110 hover:shadow-[0_0_40px_rgba(220,38,38,0.6)] active:scale-95 text-sm lg:text-base ${className}`}
    >
      <Flame size={18} className="mr-1" />
      EU QUERO PARTICIPAR
      <ChevronRight size={18} className="ml-1" />
    </a>
  );
}

export default function App() {
  return (
    <div className="min-h-screen bg-[#0a0505] text-white overflow-x-hidden">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700&family=Playfair+Display:wght@600;700;800;900&display=swap');
        * { font-family: 'Sora', sans-serif; }
        .font-display { font-family: 'Playfair Display', serif; font-weight: 800; }
        .font-sans { font-family: 'Sora', sans-serif; }
        .hero-bg {
          background: radial-gradient(ellipse at 65% 45%, rgba(127,29,29,0.4) 0%, rgba(59,8,8,0.2) 35%, #0a0505 75%);
        }
        .stat-card { transition: all 0.3s ease; }
        .stat-card:hover { transform: translateY(-6px); color: #ff4444; }
        .feature-card { transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1); }
        .feature-card:hover { border-color: rgba(220,38,38,0.5); transform: translateY(-4px); box-shadow: 0 20px 40px rgba(220,38,38,0.15); }
        .pain-card { transition: all 0.3s ease; }
        .pain-card:hover { border-color: rgba(220,38,38,0.5); background: rgba(220,38,38,0.08); }
        @keyframes pulse-ring {
          0% { box-shadow: 0 0 0 0 rgba(220,38,38,0.7); }
          70% { box-shadow: 0 0 0 24px rgba(220,38,38,0); }
          100% { box-shadow: 0 0 0 0 rgba(220,38,38,0); }
        }
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-12px); }
        }
        .pulse-btn { animation: pulse-ring 2.5s infinite; }
        .float-img { animation: float 3s ease-in-out infinite; }
        .gradient-text { background: linear-gradient(135deg, #ff3333, #ff6b6b); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; }
      `}</style>

      {/* HERO */}
      <section className="hero-bg min-h-screen flex items-center relative overflow-hidden pt-20">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-[#0a0505] pointer-events-none" />
        <div className="max-w-7xl mx-auto px-6 lg:px-12 py-20 w-full grid lg:grid-cols-2 gap-16 items-center relative z-10">
          <div className="space-y-10">
            <div className="inline-flex items-center gap-3 border border-red-600/60 bg-gradient-to-r from-red-950/50 to-red-900/30 rounded-full px-5 py-2.5 text-xs font-bold text-red-300 uppercase tracking-[1.5px]">
              <Flame size={16} className="text-red-500" />
              MÉTODO MAGRAFIT 30D
            </div>

            <h1 className="font-display text-5xl sm:text-5xl md:text-6xl lg:text-7xl font-black leading-[1.15] tracking-tight">
              Transforme seu corpo em <span className="gradient-text">30 dias</span> com um método que <span className="text-red-400">seca, define e fortalece</span>
            </h1>

            <p className="text-gray-300 text-lg lg:text-xl leading-relaxed max-w-2xl font-light">
              O programa exclusivo da mentora{' '}
              <strong className="font-semibold text-white">Camila Obali Molinaroli</strong>{' '}
              que une fisiologia hormonal, biomecânica e equilíbrio emocional para resultados <span className="text-red-400">reais e sustentáveis</span>.
            </p>

            <CTAButton className="pulse-btn" />

            <div className="flex flex-wrap gap-8 text-sm text-gray-400 pt-6">
              <span className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-red-950/60 flex items-center justify-center">
                  <Shield size={16} className="text-red-400" />
                </div>
                <span className="font-medium">Método Saudável</span>
              </span>
              <span className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-red-950/60 flex items-center justify-center">
                  <Clock size={16} className="text-red-400" />
                </div>
                <span className="font-medium">Apenas 30 dias</span>
              </span>
              <span className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-red-950/60 flex items-center justify-center">
                  <Star size={16} className="fill-amber-400 text-amber-400" />
                </div>
                <span className="font-medium">+500 mulheres</span>
              </span>
            </div>
          </div>

          <div className="relative flex justify-center lg:justify-end">
            <div className="relative w-full max-w-md">
              <div className="absolute -inset-8 bg-gradient-to-br from-red-700/30 via-red-800/20 to-transparent rounded-[40px] blur-3xl" />
              <div className="float-img relative rounded-[40px] overflow-hidden border-2 border-red-500/40 shadow-2xl">
                <img
                  src="/IMG_2739.JPG.jpeg"
                  alt="Camila Obali Molinaroli treinando"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent" />
              </div>
              <div className="absolute -bottom-4 -left-4 bg-gradient-to-br from-red-600 to-red-700 rounded-2xl p-5 shadow-2xl border border-red-400/30">
                <p className="text-xs text-red-100 font-semibold uppercase tracking-widest mb-1">Resultado médio</p>
                <p className="text-2xl font-black text-white">-5kg</p>
                <p className="text-xs text-red-100 font-medium">em 30 dias</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* STATS */}
      <section className="bg-gradient-to-b from-[#0a0505] via-[#110a0a] to-[#0a0505] border-y border-red-900/40 py-20">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
            {[
              { value: '+500', label: 'Alunas transformadas', icon: '👩‍🏫' },
              { value: '30', label: 'Dias de resultado', icon: '⚡' },
              { value: '98%', label: 'De satisfação', icon: '🎯' },
              { value: '0', label: 'Treinos extremos', icon: '💪' },
            ].map((s) => (
              <div key={s.label} className="stat-card text-center group cursor-default">
                <div className="text-3xl md:text-4xl mb-3">{s.icon}</div>
                <p className="font-display text-5xl md:text-6xl font-black text-red-500 group-hover:text-red-400">{s.value}</p>
                <p className="text-gray-400 mt-2 text-sm font-medium">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PAIN POINTS */}
      <section className="py-24 px-6 max-w-6xl mx-auto">
        <div className="text-center mb-20">
          <p className="text-red-400 uppercase tracking-[2px] text-xs font-bold mb-4">Você se identifica?</p>
          <h2 className="font-display text-5xl md:text-6xl font-black leading-tight mb-6">
            Se sente assim?<br/>
            <span className="gradient-text">Temos a solução!</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto font-light">
            O MAGRAFIT 30D foi criado exclusivamente para mulheres que querem resultados reais, sem sofrimento ou sacrifício extremo.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          {[
            'Já tentou várias dietas e nada funcionou de verdade',
            'Tem ansiedade ou compulsão alimentar',
            'Não tem tempo para horas de academia',
            'Quer um corpo definido sem perder a saúde',
            'Sente cansaço, falta de energia ou desânimo',
            'Quer um método guiado por uma especialista',
          ].map((item) => (
            <div
              key={item}
              className="pain-card flex items-center gap-4 border border-white/8 bg-white/3 rounded-2xl p-5 transition-all duration-300 cursor-default"
            >
              <CheckCircle size={22} className="text-red-500 flex-shrink-0" />
              <p className="text-gray-200">{item}</p>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <CTAButton />
        </div>
      </section>

      {/* MENTOR */}
      <section className="py-24 px-6 bg-gradient-to-b from-[#0a0505] to-[#110a0a]">
        <div className="max-w-6xl mx-auto grid lg:grid-cols-2 gap-16 items-center">
          <div className="relative order-2 lg:order-1">
            <div className="absolute -inset-6 bg-gradient-to-br from-red-700/25 via-red-800/15 to-transparent rounded-[40px] blur-3xl" />
            <div className="float-img relative rounded-[40px] overflow-hidden border-2 border-red-500/40 shadow-2xl">
              <img
                src="/IMG_2739.JPG.jpeg"
                alt="Camila Obali Molinaroli"
                className="relative w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
            </div>
          </div>
          <div className="space-y-10 order-1 lg:order-2">
            <div>
              <p className="text-red-400 uppercase tracking-[2px] text-xs font-bold mb-4">Sua mentora</p>
              <h2 className="font-display text-5xl md:text-6xl font-black leading-tight">
                Camila Obali <span className="gradient-text">Molinaroli</span>
              </h2>
            </div>
            <p className="text-gray-300 text-lg lg:text-xl leading-relaxed font-light">
              Especialista em transformação corporal que <span className="text-red-400 font-semibold">ajuda mulheres a conquistarem o corpo dos sonhos</span> em até 30 dias, através de um processo saudável, sem dores e com resultados <span className="text-red-400 font-semibold">100% sustentáveis</span>.
            </p>
            <div className="grid grid-cols-2 gap-4">
              {[
                { icon: <Zap size={18} />, title: 'Especialista em Flow', desc: 'Equilíbrio entre corpo e mente para alta performance e bem-estar.' },
                { icon: <Heart size={18} />, title: 'Saúde da Mulher', desc: 'Fisiologia hormonal e emagrecimento feminino com base científica.' },
                { icon: <Activity size={18} />, title: 'Biomecânica Aplicada', desc: 'Reabilitação, movimento correto e prevenção de lesões.' },
                { icon: <Dumbbell size={18} />, title: 'Pilates & Musculação', desc: 'Fortalecimento, consciência corporal e reeducação postural.' },
              ].map((card) => (
                <div key={card.title} className="feature-card border border-white/8 bg-white/3 rounded-2xl p-4 transition-all duration-300">
                  <div className="text-red-500 mb-2">{card.icon}</div>
                  <p className="font-semibold text-sm mb-1">{card.title}</p>
                  <p className="text-gray-400 text-xs leading-relaxed">{card.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* METHOD */}
      <section className="py-24 px-6 bg-[#0a0505]">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-20">
            <p className="text-red-400 uppercase tracking-[2px] text-xs font-bold mb-4">O método completo</p>
            <h2 className="font-display text-5xl md:text-6xl font-black leading-tight mb-6">
              Tudo que você <span className="gradient-text">conquista</span><br/>
              em 30 dias
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-5">
            {[
              { title: 'Plano Alimentar Personalizado', desc: 'Cardápio adaptado à sua rotina, hormônios e objetivo.' },
              { title: 'Treinos em Casa ou Academia', desc: '30 a 40 minutos por dia, sem treinos extremos.' },
              { title: 'Acompanhamento por WhatsApp', desc: 'Suporte direto com a Camila durante todo o processo.' },
              { title: 'Protocolo Hormonal Feminino', desc: 'Estratégias para equilíbrio hormonal e queima de gordura.' },
              { title: 'Mentoria de Mindset & Flow', desc: 'Saia da ansiedade e compulsão de forma definitiva.' },
              { title: 'Comunidade Exclusiva', desc: 'Grupo de mulheres em transformação para te motivar.' },
            ].map((item) => (
              <div key={item.title} className="feature-card border border-white/8 bg-white/3 rounded-2xl p-6 transition-all duration-300">
                <div className="w-10 h-10 bg-red-600 rounded-full flex items-center justify-center mb-5">
                  <CheckCircle size={18} />
                </div>
                <p className="font-bold text-lg mb-2">{item.title}</p>
                <p className="text-gray-400 text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>

          <div className="mt-16 text-center">
            <CTAButton />
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="py-24 px-6 bg-gradient-to-b from-[#0a0505] to-[#110a0a]">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-20">
            <p className="text-red-400 uppercase tracking-[2px] text-xs font-bold mb-4">Histórias reais</p>
            <h2 className="font-display text-5xl md:text-6xl font-black leading-tight">
              Mulheres que <span className="gradient-text">transformaram</span><br/>
              suas vidas
            </h2>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              { name: 'Ana Carolina', result: '-7kg em 30 dias', text: 'Nunca imaginei que conseguiria emagrecer sem passar fome. O método da Camila mudou minha relação com a comida e com meu corpo.' },
              { name: 'Juliana Martins', result: '-5kg em 28 dias', text: 'Tentei tudo e nada funcionava. Com o MAGRAFIT aprendi a respeitar meu ciclo hormonal e os resultados foram incríveis.' },
              { name: 'Fernanda Lima', result: '-6kg em 30 dias', text: 'O acompanhamento personalizado faz toda a diferença. Me sinto mais forte, disposta e finalmente com o corpo que queria.' },
            ].map((t) => (
              <div key={t.name} className="border border-white/8 bg-white/3 rounded-2xl p-6 space-y-4">
                <div className="flex gap-0.5">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} size={14} className="fill-amber-400 text-amber-400" />
                  ))}
                </div>
                <p className="text-gray-300 text-sm leading-relaxed italic">"{t.text}"</p>
                <div>
                  <p className="font-semibold text-white">{t.name}</p>
                  <p className="text-red-400 text-sm font-bold">{t.result}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FINAL CTA */}
      <section className="py-32 px-6 text-center relative overflow-hidden">
        <div
          className="absolute inset-0 pointer-events-none"
          style={{ background: 'radial-gradient(ellipse at center, rgba(127,29,29,0.3) 0%, #0a0505 70%)' }}
        />
        <div className="relative z-10 max-w-3xl mx-auto space-y-10">
          <div className="inline-flex items-center gap-3 border border-red-600/60 bg-gradient-to-r from-red-950/50 to-red-900/30 rounded-full px-6 py-2.5 text-xs font-bold text-red-300 uppercase tracking-[1.5px]">
            <Flame size={16} className="text-red-500" />
            Vagas limitadas para este mês
          </div>
          <h2 className="font-display text-6xl md:text-7xl font-black leading-[1.1]">
            Sua transformação<br/>
            <span className="gradient-text">começa agora</span>
          </h2>
          <p className="text-gray-300 text-xl lg:text-2xl leading-relaxed font-light max-w-2xl mx-auto">
            Entre no grupo exclusivo e dê o primeiro passo para transformar seu corpo em 30 dias com <span className="text-red-400 font-semibold">método, ciência e suporte real</span>.
          </p>
          <CTAButton className="pulse-btn mt-8" />
          <p className="text-gray-500 text-sm font-medium">Sem compromisso • Suporte direto no WhatsApp • Comunidade exclusiva</p>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="border-t border-white/8 py-8 px-6 text-center text-gray-600 text-sm bg-[#0d0707]">
        <p>&copy; 2026 MAGRAFIT 30D &mdash; Camila Obali Molinaroli. Todos os direitos reservados.</p>
      </footer>

      {/* FLOATING WHATSAPP */}
      <a
        href={WHATSAPP_LINK}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-8 right-8 z-50 flex items-center gap-3 bg-gradient-to-r from-green-500 to-green-400 hover:from-green-400 hover:to-green-300 text-white font-bold px-6 py-4 rounded-full shadow-[0_8px_32px_rgba(34,197,94,0.4)] transition-all duration-300 hover:scale-110 active:scale-95 group"
      >
        <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor" className="group-hover:animate-pulse">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
        </svg>
        <span className="text-sm md:text-base">Entrar no grupo</span>
      </a>
    </div>
  );
}
